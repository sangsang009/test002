const myName = document.getElementById('my-name');
console.log(myName.innerText);
